﻿using System;

namespace SquareNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            SquareNumbers numbers = new SquareNumbers();
            int i = 0;
            int noSquare = 0;
            int total = 0;
            int countEven = 0;
            int countOdd = 0;
            double average = 0.0;
            int maxValue = 0;
            int minValue = 0;
            Console.WriteLine("The First 20 Square Numbers :");
            numbers.displaySquareNum();

           

            Console.WriteLine("Even Numbers :");
            for (i = 1; i <= 20; i++)
            {
                noSquare = i * i;
                if (noSquare % 2 == 0)
                {
                    total = total + noSquare;
                    average = noSquare / i;
                    Console.Write(noSquare + " ");
                    countEven++;
                    average = total / countEven;

                    if (noSquare < minValue)
                    {
                        minValue = noSquare;
                    }
                   else
                    {
                        maxValue = noSquare;
                    }


                }
            }
           
            Console.WriteLine();
            Console.WriteLine("the Total number of even numbers is " + total);
            Console.WriteLine("The Amount of Even numbers is " + countEven);
            Console.WriteLine("The Average number of odd numbers " + average);
            Console.WriteLine("The maximum value of even numbers is " + maxValue);
            Console.WriteLine("The minimum value of even numbers is " + minValue);
            Console.WriteLine("\nOdd Numbers :");
           
            for (i = 1; i <= 20; i++)
            {
                noSquare = i * i;
                if (noSquare % 2 != 0)
                {
                    total = total + noSquare;
                   
                    Console.Write(noSquare + " ");
                    countOdd++;
                    average = total / countOdd;

                    if (noSquare < minValue)
                    {
                        minValue = noSquare;
                    }
                    else
                    {
                        maxValue = noSquare;
                    }
                }
              
            }

            Console.WriteLine();
            Console.WriteLine("the Total number of odd numbers is " + total);
            Console.WriteLine("The Amount of odd numbers is " + countOdd);
            Console.WriteLine("The Average number of odd numbers " + average);
            Console.WriteLine("The maximum value of odd numbers is " + maxValue);
            Console.WriteLine("The minimum value of odd numbers is " + minValue);

        }
    }
    class SquareNumbers
    {
        //int squareNum = 0;
        public int displaySquareNum()
        {
            int num;
            for (num = 1; num < 21; num++)
            {
                int  squareNum = num * num;
                Console.WriteLine("{0} {1} ", num, squareNum);

            }
            Console.WriteLine("=================================");
            //Console.ReadKey();
            return num;
            
        }
       
       
    }
   
    
       
       
    
}
